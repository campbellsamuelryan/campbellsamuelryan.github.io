#!/bin/bash
count=5
total_t=0

echo "Please enter the exponent for counter.cpp"
read input


if [[$input == "quit"]] ; then
    exit 0
fi

for (( i=1; i <=count; ++i)) ; 
do
    echo "Running iteration $i..."
    time=`./a.out $input`
    echo "time taken: $time ms" 
    total_t=`expr $total_t + $time`
done

average_t=`expr $total_t / $count`
echo " $count iterations took $total_t"
echo "Average time was $average_t ms"