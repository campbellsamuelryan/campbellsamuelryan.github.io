/*
Samuel Campbell
"postfixCalculator.h"
*/
#ifndef POSTFIXCALCULATOR_H
#define POSTFIXCALCULATOR_H

#include <iostream>
#include "stack.h"
#include "ListNode.h"
#include "ListItr.h"
using namespace std;

class postfixCalculator {
    public:
        postfixCalculator();      
        ~postfixCalculator();  

        void add();            
        void subtract();        
        void multiply(); 
        void divide();     
        void negate();    
        int getTopValue();  
        void addNum(int x); 
        void calculator();   
    private:
        stack stack1;
};
#endif