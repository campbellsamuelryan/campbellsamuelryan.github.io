/*
Samuel Campbell
"List.cpp"
*/
#include <iostream>
#include <string>
#include "List.h"
#include "ListNode.h"
using namespace std;

List::List() {
  head = new ListNode();
  tail = new ListNode();
  head->next=tail;
  tail->previous=head;
  count = 0;
}

// Copy constructor
// Called when the code looks something like List list2 = list1;
// (In other words, it is called when you are trying to construct a **new** list from an existing one)
List::List(const List& source) {
    head=new ListNode();
    tail=new ListNode();
    head->next=tail;
    tail->previous=head;
    count=0;

    // Make a deep copy of the list
    ListItr iter(source.head->next);
    while (!iter.isPastEnd()) {
        insertAtTail(iter.retrieve());
        iter.moveForward();
    }
}
// Copy assignment operator
// Called when the code looks something like list2 = list1;
// (In other words, it is called when you are trying to set an **existing** list equal to another one)
List& List::operator=(const List& source) {
    if (this == &source) {
        // The two are the same list; no need to do anything
        return *this;
    } else {
        // Clear out anything this list contained
        // before copying over the items from the other list
        makeEmpty();

        // Make a deep copy of the list
        ListItr iter(source.head->next);
        while (!iter.isPastEnd()) {
            insertAtTail(iter.retrieve());
            iter.moveForward();
        }
    }
    return *this;
}

List::~List(){
  delete head;
  delete tail;
}

bool List::isEmpty() const {
  if(head->next == tail && tail->previous == head){
  return true;
  }else{return false;}
}

void List::makeEmpty() {
  if(isEmpty()==false){
  ListItr Node;
  while(Node.current != NULL){
    Node.current=head->next;
    delete head;
    head=Node.current;
  }
  head = new ListNode();
  tail = new ListNode();
  head->next=tail;
  tail->previous=head;
  }
}

void List::insertAfter(int x, ListItr position){
  ListNode * NewNode = new ListNode();
  NewNode->value = x;
  //Setting the pointers to the next node and previous in the linked list
  NewNode->previous  = position.current;
  NewNode->next = position.current->next;
  //reset the nodes of the current Node
  position.current->next->previous = NewNode;
  position.current->next = NewNode;

}

void List::insertBefore(int x, ListItr position){
  //Allocate the node
  ListNode * NewNode = new ListNode();
  //Allocating the data
  NewNode->value = x;
  //Setting the pointers to the next node and previous in the linked list
  NewNode->previous = position.current->previous;
  NewNode->next = position.current;
  //reset the nodes of the current Node
  position.current->previous->next = NewNode;
  position.current->previous = NewNode;
}

void List::insertAtTail(int x){
  ListNode * NewNode = new ListNode();
  NewNode->value=x;
  NewNode->previous = tail->previous;
  NewNode->next = tail;
  tail->previous->next = NewNode;
  tail->previous = NewNode;
}

ListItr List::first(){
  return ListItr(head->next);
}

ListItr List::last(){
  return ListItr(tail->previous);
}

ListItr List::find(int x){
  ListItr * find = new ListItr();
  find->current = head;
  while(!find->current){
    if(find->current->value == x){
      return *find;
    }else{
      find->current = find->current->next;
    }
  }
    find->current = tail;
    return *find;
}

void List::remove(int x){
  ListItr * remove = new ListItr();
  *remove=find(x);
  remove->current->next->previous = remove->current->previous;
  remove->current->previous->next = remove->current->next;
}

int List::size() const {
  ListItr Node;
  Node.current = head;
  int size = 0;
  while(Node.current != tail){
    size = size + 1;
    Node.current = Node.current->next;
  }
  return size-1;
}

void printList(List& source, bool forward){

  ListItr* Node = new ListItr(source.first());

  if(forward){
    while(Node->isPastEnd()==false){
      cout << Node->retrieve() <<" ";
      Node->moveForward();
    }
    cout<<endl;
  }else{
  Node = new ListItr(source.last());
    while(Node->isPastBeginning()==false){
      cout << Node->retrieve() << " " ;
      Node->moveBackward();
    }
    cout<<endl;
  }
}
void List::deleteAtLast(){
 if (isEmpty()==false){
   ListItr deleteList;
   deleteList = last();
   deleteList.current->next->previous = deleteList.current->previous;
   deleteList.current->previous->next = tail;
   delete deleteList.current;
 }
}

