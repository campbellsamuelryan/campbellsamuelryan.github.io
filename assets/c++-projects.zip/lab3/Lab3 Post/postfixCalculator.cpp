/*
Samuel Campbell
"postfixCalculator.cpp"
*/

#include <iostream>
#include "List.h"
#include "ListItr.h"
#include "stack.h"
#include "ListNode.h"
#include "postfixCalculator.h"
using namespace std;

//constructor
postfixCalculator::postfixCalculator(){
  
}
//destructor
postfixCalculator::~postfixCalculator(){

}

// addition
void postfixCalculator::add() {
    int a = stack1.top();
    stack1.pop();
    int b = stack1.top();
    stack1.pop();
    stack1.push(b + a);
}

// subtraction
void postfixCalculator::subtract() {
    int a = stack1.top();
    stack1.pop();
    int b = stack1.top();
    stack1.pop();
    stack1.push(b - a);
}
void postfixCalculator::multiply() {
    int a = stack1.top();
    stack1.pop();
    int b = stack1.top();
    stack1.pop();
    stack1.push(b * a);
}
void postfixCalculator::divide() {
    int a = stack1.top();
    stack1.pop();
    int b = stack1.top();
    stack1.pop();
    stack1.push(b / a);
}

void postfixCalculator::negate() {
    int a = stack1.top();
    stack1.pop();
    stack1.push(-a);
}
int postfixCalculator::getTopValue() {
    return stack1.top();
}
void postfixCalculator::addNum(int a) {
    stack1.push(a);
}