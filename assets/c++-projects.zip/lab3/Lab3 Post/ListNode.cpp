/*
Samuel Campbell
"ListNode.cpp"
*/

#include <iostream>
#include <string>
#include "List.h"
#include "ListNode.h"
#include "ListItr.h"

using namespace std;
ListNode::ListNode(){
    value = 0;
    //Pointers
    next = NULL;
    previous = NULL;

}
