/*
Samuel Campbell
"stack.h"
*/

#ifndef STACK_H
#define STACK_H


#include<iostream>
#include"List.h"
#include"ListItr.h"
#include "ListNode.h"


using namespace std;

class stack{
    public:
        stack();
        ~stack();

        int top();
        void push(int a);
        void pop();
        bool empty();

    private:
        List listStack;


};

#endif