#include <sstream>
#include <iostream>
#include <stack>
#include <string>


using namespace std;
#include "postfixCalculator.h"



int main(){
    postfixCalculator* px = new postfixCalculator();
    cout << "Welcome to the PostFix Calculator." << endl;

    stack<int> calcStack;
    string input;
    while (true) {
        // display prompt
        cout << ">>";

        // get input
        cin >> input;
        // check for numeric value. if we have a numeric value, this condition will be true, and we push the num to stack.
        int num;
        if (istringstream(input) >> num) {
            calcStack.push(num);
        }

            // check for operator
        else if (isOperator(input)) {
            performOp(input, calcStack);
        }

            // check for quit
        else if (input == "q") {
            return 0; // Quit program
        }

            // invalid output statement
        else {
            cout << "Invalid input" << endl;
        }
    }
    return 0;
}