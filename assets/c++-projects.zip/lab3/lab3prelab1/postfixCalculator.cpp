//
// Created by Samuel Campbell on 2/5/22.
//

#include "postfixCalculator.h"

/*
 File: postfixCalculator.cpp
 Author: Samuel Campbell
 */
#include "postfixCalculator.h"
#include <stack>
#include <string>
#include <iostream>

/*
 Say you enter 1 2

 It places 1 and 2 on the stack (the operands)
 - As soon as we hit an operator (+), it will POP them off
 and APPLY that OPERATOR. 1 and 2 get popped off, as soon as
 I hit the + operator it applies it to them.
 - NEXT, it PUSHES ON the result of that value, which is 3!
 */
using namespace std;

postfixCalculator::postfixCalculator() = default;

bool postfixCalculator::isOperator(const string& input) {
    string ops[] = {"+", "-", "*", "/"};

    for(int i = 0; i < 4; i++) {
        if(input == ops[i]) {
            return true;
        }
    }
    return false; //if we go through the entire loop and dont find a match, ret false
}


void postfixCalculator::performOp(const string &input, stack<int> &calcStack) {
    int leftOperand, rightOperand, result;

    rightOperand = calcStack.top(); // retrieves value on top
    calcStack.pop(); // gets right hand value, pops it off
    // Left Operand
    leftOperand = calcStack.top();
    calcStack.pop();

    if(input == "-") {
        result = leftOperand - rightOperand;
    } else if(input == "+") {
        result = leftOperand + rightOperand;
    } else if(input == "*") {
        result = leftOperand * rightOperand;
    } else {
        result = leftOperand / rightOperand;
    }
    cout << "Your result is: " << result << endl;
    // Push result to stack! or we wont have it available for future ops.
    calcStack.push(result);
}

void postfixCalculator::add() {

}

void postfixCalculator::subtract() {

}
