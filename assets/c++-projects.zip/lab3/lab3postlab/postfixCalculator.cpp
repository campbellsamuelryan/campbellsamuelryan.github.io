/*
 File: postfixCalculator.cpp
 Author: Samuel Campbell
 */
#include "postfixCalculator.h"
#include<iostream>
#include <cstdlib>
#include<stack>

using namespace std;



postfixCalculator::postfixCalculator() {
    myStack = new Stack;
}

void postfixCalculator::add() {
    
}

void postfixCalculator::subtract() {
    
}

// push: Inserts a new element at the top of the stack, above its current top element.
void postfixCalculator::push(int e) {
    
}

// pop: Removes the top element on the stack, thereby decrementing its size by one.
void postfixCalculator::pop() {
    
}

// Returns the top element present in the stack without modifying the stack.
int postfixCalculator::top() const {
    return 0;
}

//  empty: Returns true if the stack is empty, i.e., its size is zero; otherwise, it returns false.
bool postfixCalculator::empty() const {
    return false;
}

// size: Returns the count of elements present in the stack.
int postfixCalculator::size() const {
    return 0;
}



/*
int runPostfix (string s) {
    stack<int> myStack;
    int op1, op2 = 0;
    for (int i = 0; i < s.length(); i++) {
        if (s[i] == " " || s[i] == ""){
            continue;
        }
        else if (isACharacter.(s[i])) {
            op1 = myStack.top();
            myStack.pop();
            op2 = myStack.top();
            myStack.pop;
            
            int result = (s[i], op1, op2);
        }
            else if(isNumerical(s[i])){
                        // Extract the numeric operand from the string, keep incrementing i as long as you are getting a numeric digit.
                int o3 = 0;
                while(i < s.length() && s.isNumerical(s[i])) {
                    // For a number with more than one digits, as we are scanning from left to right.
                    o3 = (o3*10) + (s[i] - '0');
                    i++;
                }
                    i--;
                    myStack.push(o3);
            }
        }
    }


boolean isACharacter (char x) {
    if (x == '+' || x == '-' || x == '*' || x == '/') {
        return true;
    } else {
        return false;
    }
}


boolean isNumerical (char x) {
    if (x < 0 || x > 9) {
        return true;
    } else {
        return false;
    }
}


int returnPostfixValue (char x, int o1, int o2)  {
    if (x == '+') {
        return o1 + o2;
    } else if (x == '-') {
        return o1 - o2;
    } else if (x == '*') {
        return o1 * o2;
    } else if (x == '/') {
        return o1/o2;
    }
}

double scanner(char x){
   int val;
   val = x;
    
   
   return double(val-'0');
    
}
*/
