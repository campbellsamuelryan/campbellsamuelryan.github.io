/*
Filename: PostfixCalculator.h
Samuel Campbell
02/04/2022
*/
#ifndef POSTFIXCALCULATOR_H
#define POSTFIXCALCULATOR_H

#include <vector>
#include <stack>

using namespace std;

template <Integer>
class postfixCalculator {
    public:
    postfixCalculator(int = 5);
    ~postfixCalculator() {
        delete [] myPtr;
    };
    int pop(int&);
    int isEmpty() const {
        return top == -1;
    }
    
    int isFull() const {
        return top == size - 1;
    }

private:
        int size;
        int top;
        int * myPtr; // pointer holds spot in mem
};

#endif
