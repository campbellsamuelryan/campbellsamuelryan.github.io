/*
 File: postfixCalculator.cpp
 Author: Samuel Campbell
 */
#include "postfixCalculator.h"
#include <stack>
#include <string>
#include <iostream>

/*
 Say you enter 1 2

 It places 1 and 2 on the stack (the operands)
 - As soon as we hit an operator (+), it will POP them off
 and APPLY that OPERATOR. 1 and 2 get popped off, as soon as
 I hit the + operator it applies it to them.
 - NEXT, it PUSHES ON the result of that value, which is 3!
 */
using namespace std;

postfixCalculator::postfixCalculator() {
    
}

bool postfixCalculator::theOperator(const string& userInput) {
    string ops[] = {"+", "-", "*", "/"};

    for(int i = 0; i < 4; i++) {
        if(userInput == ops[i]) {
            return true;
        }
    }
    return false; //if we go through the entire loop and dont find a match, ret false
}
 


void postfixCalculator::theOperation(const string& userInput, stack<int>& myStack) {
    int leftOperand, rightOperand, result;

    rightOperand = myStack.top(); // retrieves value on top
    myStack.pop(); // gets right hand value, pops it off
    // Left Operand
    leftOperand = myStack.top();
    myStack.pop();

    if(userInput == "-") {
        result = leftOperand - rightOperand;
    } else if(userInput == "+") {
        result = leftOperand + rightOperand;
    } else if(userInput == "*") {
        result = leftOperand * rightOperand;
    } else {
        result = leftOperand / rightOperand;
    }
    cout << "Your result is: " << result << endl;
    // Push result to stack! or we wont have it available for future ops.
    myStack.push(result);
}


