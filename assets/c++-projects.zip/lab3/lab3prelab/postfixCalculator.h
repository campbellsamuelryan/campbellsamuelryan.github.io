//
// Created by Samuel Campbell on 2/5/22.
//

#ifndef POSTFIXCALCULATOR_H
#define POSTFIXCALCULATOR_H
#include <stack>
#include <string>
#include <iostream>


using namespace std;

class postfixCalculator {
    public:
        postfixCalculator();
        ~postfixCalculator();

        bool theOperator(const string& userInput);
        void theOperation(const string& userInput, stack<int>& myStack);

        //void add();
        //void subtract();

    private:

};
#endif
