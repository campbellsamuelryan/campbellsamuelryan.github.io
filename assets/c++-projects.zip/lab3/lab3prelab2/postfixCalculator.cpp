/*
 File: postfixCalculator.cpp
 Author: Samuel Campbell
 */
#include "postfixCalculator.h"
#include <stack>
#include <string>
#include <iostream>

using namespace std;






