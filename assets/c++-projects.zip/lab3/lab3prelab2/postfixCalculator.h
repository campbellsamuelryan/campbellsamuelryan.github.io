// File: PostfixCalculator.h
// Author: Samuel Campbell

#ifndef POSTFIXCALCULATOR_H
#define POSTFIXCALCULATOR_H
#include <stack>
#include <string>
#include <iostream>


using namespace std;

class postfixCalculator {
    public:
        

    private:

};
#endif
