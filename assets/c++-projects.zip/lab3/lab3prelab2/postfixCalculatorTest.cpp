#include <sstream>
#include <iostream>
#include <stack>
#include <string>
// File: PostfixCalculatorTest.cpp
// Name: Samuel Campbell


using namespace std;
#include "postfixCalculator.h"
bool theOperator(const string& userInput) {
    string operands[] = {"+", "-"/* "*", "/"*/};

    for(int i = 0; i < 4; i++) {
        if(userInput == operands[i]) {
            return true;
        }
    }
    return false;
}
 
void theOperation(const string& userInput, stack<int>& myStack) {
    int lOp;
    int rOp;
    int result;

    rOp = myStack.top();
    myStack.pop();
    lOp = myStack.top();
    myStack.pop();

    if(userInput == "-") {
        result = lOp - rOp;
    } else if(userInput == "+") {
        result = lOp + rOp;
    } else if(userInput == "*") {
        result = lOp * rOp;
    } else {
        result = lOp / rOp;
        myStack.push(result);
     }
}

int main(){
    stack<int> myStack;
    string userInput;
    while (cin >> userInput) {
        
        int x;
        if (istringstream(userInput) >> x) {
            myStack.push(x);
        } else if (theOperator(userInput)) {
            theOperation(userInput, myStack);
        } else if (userInput == "q") {
            return 0;
        } else {
            cout << "Invalid input" << endl;
        }
        
    }
    int result = myStack.top();
    cout << result << endl;
    return 0;
}
