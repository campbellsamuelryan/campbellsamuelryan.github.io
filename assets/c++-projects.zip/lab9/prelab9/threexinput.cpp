/*
Samuel C
CS2150
'threexinput.cpp'
*/

#include <iostream>
#include <cstdlib>
#include "timer.cpp"


using namespace std;
extern "C" int threexplusone(int);


int main(){
    int x;
    int n;
    int result;
    double time;
    timer t;
    cout<<"Enter a number: "<<endl;
    cin>>x;
    cout<<"Enter iterations of subroutine:"<<endl;
    cin>>n;

    t.start();
    int i;
    for(i=0; i < n; i++){
        result = threexplusone(x);

    }
    t.stop();
    time = t.getTime();
    time = time/n;
    cout<<"Steps: "<<result<<endl;
    //cout<<"It took an average of"<< time <<" seconds for "<<x<<" to reach the value of 1 in "<< result <<" steps within "<<n<<" iterations"<<endl;

    return 0;
}   
