/*
 File Name: BankAccount.cpp
 
 Author: Samuel Campbell
 Computing ID: ycn3rr
 Date: 01/25/2022
 Assignment: Post-Lab, Lab 1
*/

#ifndef BANKACCOUNT_H
#define BANKACCOUNT_H

/*
File Name: BankAccount.h
Author: Samuel Campbell
Computing ID: ycn3rr
Assignment: Post-Lab, Lab 1
Date: 01/25/2022
 */
class bankAccount {
    public:
        bankAccount(); // Default Constructor
        ~bankAccount();  // Destructor
        bankAccount(double amount); // One-Parameter Constructor, creates a bankAccount object with an initial balance
        
        double withdraw(double amount);
        double deposit(double amount);
        
        double getBalance() const;
    private:
        double balance;
};
#endif
