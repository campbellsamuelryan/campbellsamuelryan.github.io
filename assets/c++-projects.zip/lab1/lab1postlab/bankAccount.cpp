/*
 File Name: BankAccount.cpp
 
 Author: Samuel Campbell
 Computing ID: ycn3rr
 Date: 01/25/2022
 Assignment: Post-Lab, Lab 1
*/

#include <iostream>
#include "bankAccount.h"

bankAccount::bankAccount() {
    balance = 0.00;
}

bankAccount::bankAccount(double amount) {
    balance = amount;
}

bankAccount::~bankAccount() {
}

double bankAccount::withdraw(double amount) {
    if (amount > balance) {
        return balance;
    } else {
        double withdrawResult = balance - amount;
        balance = withdrawResult;
        return balance;
    }
}

double bankAccount::deposit(double amount) {
    double depositResult = balance + amount;
    balance = depositResult;
    return balance;
}
    
double bankAccount::getBalance() const {
    return balance;
}


    




