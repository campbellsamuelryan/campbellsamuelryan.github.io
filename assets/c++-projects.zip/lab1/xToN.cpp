/*
'xToN.cpp'
Author: Samuel Campbell
Computing ID: ycn3rr
08/28/2022
*/

#include <iostream>
using namespace std;

int xton(int x, int n);

int main() {
  int x, n, z;

  cin >> x;
  cin >> n;
  
  z = xton(x, n);

  cout << z << endl;
  
  return 0;
}

int xton(int x, int n) {
  int z;

  if(n >= 1) {
    return (x * xton(x, n - 1));
  }
  
  if(n == 0) {
    z = 1;
    return z;
  }

  if(x == 0) {
    z = 0;
    return z;
  } else {
    return 1;
  }
}