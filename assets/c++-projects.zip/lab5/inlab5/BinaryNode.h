/*
 Name: Samuel Campbell
 Date: 02/27/2022
 Assignment: Pre-lab 5
 
 Filename: 'TreeNode.cpp'
 */
#ifndef BINARYNODE_H
#define BINARYNODE_H
#include <string>
using namespace std;

class BinaryNode {
    BinaryNode();
    ~BinaryNode();

    string value;
    BinaryNode* left;
    BinaryNode* right;

    friend class BinarySearchTree;
};

#endif
