/*
 Name: Samuel Campbell
 Date: 02/27/2022
 Assignment: Pre-lab 5
 
 Filename: 'TreeNode.cpp'
 */
#include "BinaryNode.h"
#include <string>
using namespace std;

BinaryNode::BinaryNode() {
    value = "?";
    left = NULL;
    right = NULL;
}

BinaryNode::~BinaryNode() {
    delete left;
    delete right;
    left = NULL;
    right = NULL;
}
