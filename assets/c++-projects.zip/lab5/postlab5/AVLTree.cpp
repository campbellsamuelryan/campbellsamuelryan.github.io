/*
 Name: Samuel Campbell
 Date: 03/02/2022
 Assignment: Post-lab 5
 
 Filename: 'AVLTree.cpp'
 */

#include "AVLNode.h"
#include "AVLTree.h"
#include <iostream>
#include <string>
using namespace std;

AVLTree::AVLTree() {
    root = NULL;
}

AVLTree::~AVLTree() {
    delete root;
    root = NULL;
}

// insert finds a position for x in the tree and places it there, rebalancing
// as necessary.
void AVLTree::insert(const string& x) {
    root = insert(root, x);
}

// calling private insert function. recursively inserts a string in the tree
AVLNode * AVLTree::insert(AVLNode*& n, const string& x) {

    // find position to insert the node(normal bst insertion)
    if(n == NULL) { // if the passed root is empty
        return(newNode(x));
    }

    if (x < n->value) {
        n->left = insert(n->left, x);
    }else if (x > n->value) {
        n->right = insert(n->right, x);
    }else{ 
        return n;
    }

    // update height
    n->height = 1 + max(height(n->left), height(n->right));

    balance(n);
    return n;
}

// remove finds x's position in the tree and removes it, rebalancing as
// necessary.
void AVLTree::remove(const string& x) {
    root = remove(root, x);
}

// pathTo finds x in the tree and returns a string representing the path it
// took to get there.
string AVLTree::pathTo(const string& x) const {
    // vector to store the path
    vector<string> arr;
    string path = "";
    // if required node 'x' is present
    // then print the path
    if (hasPath(root, arr, x))
    {
        for (int i=0; i<arr.size()-1; i++)   
            path.append(arr[i]).append(" ");
        path.append(arr[arr.size()-1]);
        return path;
    }
     
    // 'x' is not present in the binary tree
    else
        return path;
}

// find determines whether or not x exists in the tree.
bool AVLTree::find(const string& x) const {
    return find(root, x);
}

// numNodes returns the total number of nodes in the tree.
int AVLTree::numNodes() const {
    return countNodes(root);
}

// balance makes sure that the subtree with root n maintains the AVL tree
// property, namely that the balance factor of n is either -1, 0, or 1.
void AVLTree::balance(AVLNode*& n) {
    // check the balance factor of the node
    int balanceFactor;
    if(n == NULL)
        balanceFactor = 0;
    else
        balanceFactor = height(n->left) - height(n->right);

    // balance the tree using rotations
    // LL Rotation
    // LR Rotation (two rotations are done for this)
    if (balanceFactor > 1)
    {
        if(height(n->left->left) <= height(n->left->right))
			n->left=rotateLeft(n->left);				//left-right rotate 
		n = rotateRight(n); // right rotate
    }

    // RR Rotation
    if (balanceFactor < -1){
        if(height(n->right->right) > height(n->right->left)){			//left rotate
			n = rotateLeft(n);
		}
        else{
            n->right=rotateRight(n->right);   //right-left rotate
            n = rotateLeft(n);
        }
    }
}

// rotateLeft performs a single rotation on node n with its right child.
AVLNode* AVLTree::rotateLeft(AVLNode*& n) {

    // getting pointers to nodes that will be rotated
    AVLNode * rightChild = n->right;
    AVLNode * leftChild = rightChild->left;

    rightChild->left = n;
    n->right = leftChild;

    // updating heights of the nodes
    n->height = 1 + max(height(n->left), height(n->right));
    rightChild->height = 1 + max(height(rightChild->left), height(rightChild->right));

    // return pointer to the updated base node
    return rightChild;
}

// rotateRight performs a single rotation on node n with its left child.
AVLNode* AVLTree::rotateRight(AVLNode*& n) {

    // getting pointers to nodes that will be rotated
    AVLNode * leftChild = n->left;
    AVLNode * rightChild = leftChild->right;

    // perfoming rotations
    leftChild->right = n;
    n->left = rightChild;

    // updating heights of the nodes
    n->height = 1 + max(height(n->left), height(n->right));;
    leftChild->height = 1 + max(height(leftChild->left), height(leftChild->right));
    

    // return pointer to the updated base node
    return leftChild;
}

// private helper for remove to allow recursion over different nodes.
// Returns an AVLNode* that is assigned to the original node.
AVLNode* AVLTree::remove(AVLNode*& n, const string& x) {
    if (n == NULL) {
        return NULL;
    }

    // first look for x
    if (x == n->value) {
        // found
        if (n->left == NULL && n->right == NULL) {
            // no children
            delete n;
            n = NULL;
            return NULL;
        } else if (n->left == NULL) {
            // Single child (left)
            AVLNode* temp = n->right;
            n->right = NULL;
            delete n;
            n = NULL;
            return temp;
        } else if (n->right == NULL) {
            // Single child (right)
            AVLNode* temp = n->left;
            n->left = NULL;
            delete n;
            n = NULL;
            return temp;
        } else {
            // two children -- tree may become unbalanced after deleting n
            string sr = min(n->right);
            n->value = sr;
            n->right = remove(n->right, sr);
        }
    } else if (x < n->value) {
        n->left = remove(n->left, x);
    } else {
        n->right = remove(n->right, x);
    }

    // Recalculate heights and balance this subtree
    n->height = 1 + max(height(n->left), height(n->right));
    balance(n);

    return n;
}

// min finds the string with the smallest value in a subtree.
string AVLTree::min(AVLNode* node) const {
    // go to bottom-left node
    if (node->left == NULL) {
        return node->value;
    }
    return min(node->left);
}

// height returns the value of the height field in a node.
// If the node is null, it returns -1.
int AVLTree::height(AVLNode* node) const {
    if (node == NULL) {
        return -1;
    }
    return node->height;
}

// max returns the greater of two integers.
int max(int a, int b) {
    if (a > b) {
        return a;
    }
    return b;
}

// Helper function to print branches of the binary tree
// You do not need to know how this function works.
void showTrunks(Trunk* p) {
    if (p == NULL) return;
    showTrunks(p->prev);
    cout << p->str;
}

// Recursive function to print binary tree
// It uses inorder traversal
void AVLTree::printTree(AVLNode* root, Trunk* prev, bool isRight) {
    if (root == NULL) return;

    string prev_str = "    ";
    Trunk* trunk = new Trunk(prev, prev_str);

    printTree(root->right, trunk, true);

    if (!prev)
        trunk->str = "---";
    else if (isRight) {
        trunk->str = ".---";
        prev_str = "   |";
    } else {
        trunk->str = "`---";
        prev->str = prev_str;
    }

    showTrunks(trunk);
    cout << root->value << endl;

    if (prev) prev->str = prev_str;
    trunk->str = "   |";

    printTree(root->left, trunk, false);

    delete trunk;
}

// creates a new node
AVLNode* AVLTree::newNode(string x){ 
    AVLNode* node = new AVLNode();
    node->value = x;
    node->left = NULL;
    node->right = NULL;
    node->height = 0; 

    return(node);
}

bool AVLTree::find(AVLNode * root, const string& x) const {
    if (root == NULL){
        return false;
    } else if (root->value == x){
        return true;
    } else if (root->value > x){
        bool isFound = find(root->left, x);
        return isFound;
    }else {
        bool isFound = find(root->right, x);
        return isFound;
    }
}

// recursively counts nodes
int AVLTree::countNodes(AVLNode * root) const {
    if (root == NULL)
        return 0;
    return 1 + countNodes(root->left) + countNodes(root->right);
}

//finds path of a value if it exists in the tree
bool AVLTree::hasPath(AVLNode * root, vector<string>& arr, string x) const{
    // if root is NULL
    // there is no path
    if (!root)
        return false;
     
    // push the node's value in 'arr'
    arr.push_back(root->value);   
     
    // if it is the required node
    // return true
    if (root->value == x)   
        return true;
     
    // else check whether the required node lies
    // in the left subtree or right subtree of
    // the current node
    if (hasPath(root->left, arr, x) ||
        hasPath(root->right, arr, x))
        return true;
     
    // required node does not lie either in the
    // left or right subtree of the current node
    // so remove current node's value from
    // 'arr'and then return false   
    arr.pop_back();
    return false;           
}

void AVLTree::printTree() {
    printTree(root, NULL, false);
}
