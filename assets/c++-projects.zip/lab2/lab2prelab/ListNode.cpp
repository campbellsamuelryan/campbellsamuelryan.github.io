/*
FILENAME: "ListNode.cpp"

Author: Samuel Campbell
Date: 01/31/2022

Lab 2 Pre-Lab

*/
#include <iostream>
#include "ListNode.h"

using namespace std;

ListNode::ListNode() {
    value = 0;
    next = NULL;
    previous = NULL;
}


