#!/bin/bash
echo 'Input dictionary'
read dict
echo 'Input grid files'
read grid # get grid file

RUNNING_TIME=`./a.out $dict $grid | tail -1`
total=$RUNNING_TIME

RUNNING_TIME=`./a.out $dict $grid | tail -1`
total=$((total + RUNNING_TIME))

RUNNING_TIME=`./a.out $dict $grid | tail -1`
total=$((total + RUNNING_TIME))

RUNNING_TIME=`./a.out $dict $grid | tail -1`
total=$((total + RUNNING_TIME))

RUNNING_TIME=`./a.out $dict $grid | tail -1`
total=$((total + RUNNING_TIME))

echo $((total/5))

