#include <iostream>
#include <string>
#include <vector>
#include <list>
#include "hashTable.h"

using namespace std;

hashTable::hashTable(int size){
    tableSize = 0;
    int prime_size = getNextPrime(size);
    table.resize(prime_size);

    for (int i = 0; i < size; i++)
    {
        table[i] = NULL;
    }
}

bool hashTable::find(string word)
{
    int index = getHash(word);
    if (table[index] == NULL)
    {
        return false;
    }
    for (list<string>::iterator i = table[index]->begin(); i != table[index]->end(); i++)
    {
        if (word == *i)
        {
            return true;
        }
    }
    return false;
}

void hashTable::insert(string word)
{
    if (word.length() > tableSize)
    {
        tableSize = word.length();
    }

    int index = getHash(word);
    if (table[index] == NULL)
    {
        table[index] = new list<string>;
    }
    table[index]->push_back(word);
}

int hashTable::getHash(string word)
{ 
    unsigned int index = 0;

    for (int i = 0; i < word.length(); i++)
    {
        index = (index * 37) + word[i];
    }
    return index % table.size();
}

bool hashTable::checkprime(unsigned int p)
{
    if (p <= 1) // 0 and 1 are not primes; the are both special cases
        return false;
    if (p == 2) // 2 is prime
        return true;
    if (p % 2 == 0) // even numbers other than 2 are not prime
        return false;
    for (int i = 3; i * i <= p; i += 2) // only go up to the sqrt of p
        if (p % i == 0)
            return false;
    return true;
}

int hashTable::getNextPrime(unsigned int n)
{
    while (!checkprime(++n))
        ;
    return n;
}