using namespace std;
#ifndef HUFFNODE_H
#define HUFFNODE_H

class huffNode {
 public:
  huffNode();
  huffNode(string d);
  ~huffNode();
  string value;
  int frequency;
  huffNode* left;
  huffNode* right;

};


#endif
