#include <cstddef>
#include <string>
#include "huffmanNode.h"

using namespace std;

huffNode::huffNode() {
  value = "";
  frequency = 0;
  left = NULL;
  right = NULL;
}
huffNode::huffNode(string d) {
  value = d;
  frequency = 1;
  left = NULL;
  right = NULL;
}