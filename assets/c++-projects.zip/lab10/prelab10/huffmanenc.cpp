#include <iostream>
#include <fstream>
#include <cstdlib>
#include <unordered_map>
#include "heap.h"
#include "huffmanNode.h"
using namespace std;

void getPrefix(unordered_map<string, string> &prefixmap, huffNode* root, string str) {
  if (root == NULL) {
    return;
  }

  if (root->value != "start") {
    string code = root->value + " " + str;
    prefixmap.insert(make_pair(root->value, str));
    cout << code << endl;
  }
  getPrefix(prefixmap, root->left, str + "0");
  getPrefix(prefixmap, root->right, str + "1");

}

// we want to use parameters
int main(int argc, char* argv[]) {
  unordered_map<string, int> charactermap;
  unordered_map<string, string> prefixmap;
  binary_heap hufftree;
  float total_count = 0;
  float compressedbits = 0;

  // verify the correct number of parameters
  if (argc != 2) {
      cout << "Must supply the input file name as the one and only parameter" << endl;
      exit(1);
  }

  // attempt to open the supplied file
  // ifstream stands for "input file stream"
  ifstream file(argv[1]);
  if (!file.is_open()) {
      cout << "File not found!";
      exit(1);
}
  // if the file wasn't found, output an error message and exit
  if (!file.is_open()) {
      cout << "Unable to open '" << argv[1] << "' for reading" << endl;
      exit(2);
  }
// read in characters one by one, until reading fails (we hit the end of the file)
  char g;
  while (file.get(g)) {
    if(int(g) > 31 && int(g) < 127) {
      string s(1, g);
      if (charactermap.find(s) == charactermap.end()) charactermap.insert(make_pair(s, 1));
      else  charactermap[s] += 1;
      total_count++;
    }

  }

  // a nice pretty separator
  cout << "----------------------------------------" << endl;
  // once we hit the end of the file we are marked as "failed", so clear that
  // then "seek" to the beginning of the file to start again
  file.clear(); // Clears the _state_ of the file, not its contents!
  file.seekg(0);

  for (auto i = charactermap.begin(); i != charactermap.end(); i++) {
    huffNode* node = new huffNode();
    node->value = i->first;
    node->frequency = i->second;
    hufftree.insert(node);
  }


  while (hufftree.size() > 1) {
    huffNode* min1 = hufftree.deleteMin();
    huffNode* min2 = hufftree.deleteMin();
    huffNode* newNode = new huffNode();
    newNode->frequency = min1->frequency + min2->frequency;
    newNode->value = "start";
    newNode->left = min1;
    newNode->right = min2;
    hufftree.insert(newNode);
  }

  
  getPrefix(prefixmap, hufftree.findMin(), "");
  cout << "----------------------------------------" << endl;

   while (file.get(g)){
     if (int(g) > 31 && int(g) < 128) {
      string s(1, g);
      if (int(g) == 32) {
        cout << prefixmap["space"] << " ";
        compressedbits += prefixmap["space"].length();
      }
     else {
       cout << prefixmap[s] << " ";
       compressedbits += prefixmap[s].length();
     }
   }
  }
   

   float compressed = total_count * 8;
   cout << endl;
   cout << '\n' << "----------------------------------------" << '\n';
   float ratio = compressed / compressedbits;
   float bits = compressedbits / total_count;
   int prefixmapSize = prefixmap.size();
    cout <<"There are a total of " << total_count <<" symbols that are outputstring."<< endl;
    cout <<"There are "<< prefixmapSize <<" distinct symbols used."<< endl;
    cout <<"There were "<< compressed <<" bits in the original file."<< endl;
    cout <<"There were "<< compressedbits <<" bits in the compressed file."<< endl;
    cout <<"This gives a compression ratio of "<<ratio<<"."<< endl;
    cout <<"The cost of the Huffman tree is "<<bits <<" bits per character."<< endl;

  return 0;
}
