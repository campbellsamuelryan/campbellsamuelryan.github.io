
#include <iostream>
#include "heap.h"
#include "huffNode.h"
#include <string>
using namespace std;

huffNode::huffNode(){
    left = NULL;
    right = NULL;
    frequency = 0;
    val = ' ';
    prefix_code = "";
}

huffNode::~huffNode() {
    delete left;
    delete right;
}

huffNode::huffNode(int freq, char char_) {
    left = NULL;
    right = NULL;
    frequency = freq;
    val = char_;
    prefix_code = "";
}

int huffNode::get_frequency() const {
    return frequency;
}
char huffNode::get_value() {
    return val;
}

void huffNode::left_right_node(huffNode* l, huffNode* r) {
    left = l;
    right = r;
}
bool huffNode::operator<(const huffNode& x) const {
    return(this->get_frequency() < x.get_frequency());
}
string huffNode::get_prefixcode() {
    return prefix_code;
}
void huffNode::set_frequency(int f) {
    frequency = f;
}
void huffNode::setvalue(char c) {
    val = c;
}
