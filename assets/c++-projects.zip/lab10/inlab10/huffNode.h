
#ifndef huffNode_H
#define huffNode_H

#include <string>
using namespace std;

class huffNode {
public:
    huffNode();
    ~huffNode();
    huffNode(int freq, char char_);

    int get_frequency() const;
    char get_value();
    string get_prefixcode();
    void set_frequency(int freq);
    void setvalue(char char_);
    void left_right_node(huffNode* lefty, huffNode* righty);
    char val;
    int frequency;
    string prefix_code;
    huffNode *left, *right;
    bool operator<(const huffNode& hn) const;

private:
    //friend class heap;
};

#endif
