
/**
 Samuel Campbell
 CS2150
 'Puzzle.cpp'
*/

#include<bits/stdc++.h>
using namespace std;

struct node {
    vector<int> state;
    node* first;
    node()    {
        first = NULL;
    }
};


/**
 *@brief  This method will compute the number of inversions in the given grid puzzle
 *
 *@param arr[] the array fro user input
 *An inversion is a pair of tiles that are in reverse order to their appearance in the goal state.
 *If an 8-puzzle has an even number of inversions, then the puzzle is solvable else its not.
 *@return number of inversions
 */
int getInversions(int arr[]){
	int inversions = 0;
    int i =0;
	while(i<8){
		for (int j = i+1; j < 9; j++){
			if (arr[j] && arr[i] && arr[i] > arr[j])
				inversions++;}
        i++;
        }
	return inversions;
}
/**
 *@brief  This method will get the number of steps taken to archieve the goal
 *
 *@param state  user input
 *@return number of steps
 */
int getSteps(node* state){
    vector<node*> path;
    while(state){
        path.push_back(state);
        state = state->first;
    }
    return path.size()-1;
}
node* createState(node* state, int x, int y){
    node* new_state = new node();
    new_state->state = state->state;
    swap(new_state->state[x], new_state->state[y]);
    return new_state;
}

/**
 *@fn Main
 *@brief  The main function of the body
 * First checks if the puzzle is solvable then proceeds to solv it
 *
 *@return if a puzzle is solvable or not, if solvable reruns number of steps
 *@todo ...
 */
int main (int argc, char **argv) {

    string s1, s2, s3;
    list <string> string_list;

    /*  // check the number of parameters
    if (argc != 6) {
        cout << "No Input was found" << endl;
        exit(0);
    }


    //argv[1] = "prelab.txt";
    ifstream file(argv[1], ifstream::binary);
    if ( !file.is_open() ) {
        cout << "Unable to open file '" << argv[1] << "'." << endl;
        return 1;
    }
    */
    int pos;
    int p[3][3];
    node* start = new node();
    vector<int> goal = {1, 2, 3, 4, 5, 6, 7, 8, 0};
    map<vector<int>, bool> Puzzle;
    string line1;

    cout<< "Enter puzzle"<<endl;


    int ii = 0;
    while(ii < 3) {
        getline(cin, line1);
        int iii = 0;
        int n;
        istringstream ss(line1);
        while (ss>>n){
            //int s = stoi(n);
            p[ii][iii] = n;
            start->state.push_back(n);
        iii++;
        }

    ii++;
    }

    cout<<"Solving puzzle"<<endl;
    ///Check if the puzzle is solvable
    int invCount = getInversions((int *)p);
    if (invCount%2 != 0){
        cout<<"IMPOSSIBLE"<<endl;

    }else{
        //its solvable so we solve it
        Puzzle[start->state] = 1;
        node *current = new node(), *child = new node();
        queue<node*> q;
        q.push(start);

        while(!q.empty()){
            current = q.front();
            q.pop();

            if(goal == current->state)
            {
                int steps = getSteps(current);
                cout<<steps<<endl;

            }

            for(int i = 0; i < 9; ++i){
                if(current->state[i] == 0){
                    pos = i;
                    break;
                }
            }

            if((pos % 3) != 0){
                child = createState(current, pos, pos-1);
                if(Puzzle[child->state] == 0){
                    Puzzle[child->state] = 1;
                    child->first = current;
                    q.push(child);
                }
            }

            if((pos % 3) != 2){
                child = createState(current, pos, pos+1);
                if(Puzzle[child->state] == 0){
                    Puzzle[child->state] = 1;
                    child->first = current;
                    q.push(child);
                }
            }

            if((pos / 3) != 0){
                child = createState(current, pos, pos-3);
                if(Puzzle[child->state] == 0){
                    Puzzle[child->state] = 1;
                    child->first = current;
                    q.push(child);
                }
            }

            if((pos / 3) != 2){
                child = createState(current, pos, pos+3);
                if(Puzzle[child->state] == 0){
                    Puzzle[child->state] = 1;
                    child->first = current;
                    q.push(child);
                }
            }
    }


}


    return 0;
}
