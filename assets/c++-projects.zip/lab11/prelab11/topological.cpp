/**
 *@author Samuel Campbell
 *@file topological.cpp
*/

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <list>
#include <stack>
#include <string>
#include <map>

using namespace std;
/**
 *@brief topological sort
 *@return return the unique elements in a sorted list of items
*/

int main (int argc, char **argv) {

    string s1, s2;
    list <string> string_list;
    list <string> uniq;

    // verify the correct number of parameters
    if (argc != 2) {
        cout << "Must supply the input file name as the one and only parameter" << endl;
        exit(1);
    }


    // attempt to open the supplied file
    //argv[1] = "prelab-test-small.txt";
    ifstream file(argv[1], ifstream::binary);
    if ( !file.is_open() ) {
        cout << "Unable to open file '" << argv[1] << "'." << endl;
        return 1;
    }


    while(true) {
      file >> s1;
      file >> s2;
        if(s1 == "0" && s2 == "0") {
            break;
        }
       // cout << s1 <<" "<< s2 << endl;

        string_list.push_back(s1);
        string_list.push_back(s2);
    }
    //cout <<"\n"<<endl;
    file.close();

    /**
        *Sort the string values in the list
        *@brief then only get the unique values
        *
    */

    string_list.sort();
    string_list.unique();
     /**
        *output_string == to store the final output
        *
    */
    string output_string = "";
    for (const auto& n : string_list) {
        output_string += n + " ";
    }
     cout <<output_string;
     return 0;
}
