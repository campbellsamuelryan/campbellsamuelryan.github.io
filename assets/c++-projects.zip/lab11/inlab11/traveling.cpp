/**
 *@author 
 *@file topological.cpp
 *@date 2022
 *
*/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

#include "middleearth.h"

/**
 *@brief  This method will compute the full distance of the cycle that starts
 *
 *@param me created world
 *@param start starting city
 *@param dests vector holding the cities to be used
 *@return distance between all of the cities
 *
 *@todo Find a faster methode to compute the distances
 */
float computeDistance(MiddleEarth &me, string start, vector<string> dests);


/**
 *@brief  This method will print the entire route.
 * starting and ending at the 'start' parameter.  The output should be of the form
 *@param start first city
 *@param dests vector holding the cities to be used
 *
 */
void printRoute(string start, vector<string> dests);

int main (int argc, char **argv) {

   // check the number of parameters
    if (argc != 6) {
        cout << "Usage: " << argv[0] << " <world_height> <world_width> "
             << "<num_cities> <random_seed> <cities_to_visit>" << endl;
        exit(0);
    }

    // we'll assume the parameters are all well-formed
    int width = stoi(argv[1]);
    int height = stoi(argv[2]);
    int num_cities = stoi(argv[3]);
    int rand_seed = stoi(argv[4]);
    int cities_to_visit = stoi(argv[5]);
    //int width = 20;
    //int height =20;
    //int num_cities = 20;
    //int rand_seed = 14;
    //int cities_to_visit =10;

  // Create the world, and select your itinerary
  MiddleEarth me(width, height, num_cities, rand_seed);
  vector<string> dests = me.getItinerary(cities_to_visit);

  // TODO: YOUR CODE HERE
  string start_position=dests[0];
  vector<string> path1=dests;
  sort(dests.begin()+1, dests.end());

  float minimum_distance=computeDistance(me, start_position, dests);

  do{
    float current_distance=computeDistance(me, start_position, dests);
    if(current_distance<minimum_distance){
      minimum_distance=current_distance;
      path1=dests;
    }
  }while(next_permutation(dests.begin()+1,dests.end()));

  cout<<"Minimum path has distance " <<minimum_distance<<" :";
  printRoute(path1[0],path1);

  return 0;
}

// This method will compute the full distance of the cycle that starts
// at the 'start' parameter, goes to each of the cities in the dests
// vector IN ORDER, and ends back at the 'start' parameter.
float computeDistance(MiddleEarth &me, string start, vector<string> dests) {
  float res;
    string start1 =start;
    string dest = dests[dests.size()-1];
    unsigned int max_size  = dests.size()-1;
    for(unsigned int i=0; i<= max_size; i++){
        res += me.getDistance(start1,dests[i]);
        start1 = dests[i];

    }
    return res += me.getDistance(dests[0], dest);
}


// This method will print the entire route, starting and ending at the
// 'start' parameter.  The output should be of the form:
// Erebor -> Khazad-dum -> Michel Delving -> Bree -> Cirith Ungol -> Erebor
void printRoute(string start, vector<string> dests) {
  // TODO: YOUR CODE HERE
    for(unsigned int i=0; i<=dests.size()-1; i++){
        cout<< dests[i]<<" -> ";
    }
    cout<<start;
}
