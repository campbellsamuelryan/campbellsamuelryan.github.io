

/*
In prelab4.cpp:
Write a sizeOfTest() function to view the sizes of various types
Write an overflow() function to investigate how C++ handles integer overflow
Write an outputBinary() function to display the binary representation of integers
Files to download: none
Files to submit: prelab4.cpp
*/

/*
 Filename: 'prelab4.cpp'
 Author: Samuel Campbell
 Date: 02/14/2022
 Assignment: Prelab 4
 */
#include <iostream>
using namespace std;
#include <cstdlib>
#include <string>
#include <vector>


void sizeOfTest() {
    cout << "Size of int: " << sizeof(int) << endl;
    cout << "Size of unsigned int: " << sizeof(unsigned int) << endl;
    cout << "Size of float: " << sizeof(float) << endl;
    cout << "Size of double: " << sizeof(double) << endl;
    cout << "Size of char: " << sizeof(char) << endl;
    cout << "Size of bool: " << sizeof(bool) << endl;
    cout << "Size of int*: " << sizeof(int*) << endl;
    cout << "Size of char*: " << sizeof(char*) << endl;
    cout << "Size of double*: " << sizeof(double*) << endl;
}
void overflow() {
    unsigned int ui_max = 4294967295;
    unsigned int ui_max_final = ui_max + 1;

    ui_max_final = ui_max + 1;
    cout << ui_max << " + 1 = " << ui_max_final << endl;

}
void outputBinary(unsigned int ui) {
    vector<int> remainderArray;
    while (ui != 0) {
        int r = ui % 2;
        ui /= 2;
        remainderArray.push_back(r);
    }
    while (remainderArray.size() != 32) {
        remainderArray.push_back(0);
    }
        
    for (int i = 31; i > -1; i--) {
        cout << remainderArray[i];
        if (i % 4 == 0) {
            cout << " ";
        }
    }
    cout<<endl;
        
}

int main() {
    string str;
    cin >> str;
    int x = atoi(str.c_str());

    sizeOfTest();
    overflow();
    outputBinary(x);
}
