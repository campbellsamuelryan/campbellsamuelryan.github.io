//'main.cpp'
//public class cat() {}


int main() {
	
	int a = 5;
	int& b = a;
	int* c = b;

	System.out.println("Here x is: " + a);
	System.out.println("Here x1 is: " + b);
	System.out.println("Here's y: " + c);
	System.out.println("Here's y1: " + d);

	return 0;
}

