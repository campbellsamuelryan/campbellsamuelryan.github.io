/*
Samuel Campbell
Pre-Lab 8
CS 2150
'mathfun.cpp'
*/

#include <iostream>
#include <cstdlib>


using namespace std;

extern "C" int product (int, int);
extern "C" int power (int, int);

int main () {
  int int_1; 
  int int_2;
  int power_;
  int product_;
  cout << "Enter integer 1: " << endl;
  cin >> int_1;
  cout << "Enter integer 2: " << endl;
  cin >> int_2;

  product_ = product(int_1, int_2);
  power_ = power(int_1, int_2);

  cout << "Product: " << product_ << endl;
  cout << "Power: " << power_ << endl;
  return 0;
}
  